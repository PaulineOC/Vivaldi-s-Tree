Fractal.js
===========

Collection of simple animated fractals implemented in Javascript and HTML5
